const { Router } = require("express");

const productRouter = Router();

productRouter.get('/', (_req, res) => {
    res.json([{
        name: 'Bolacha',
        brand: 'Trakinas',
    }]);
});

exports.productRouter = productRouter;
